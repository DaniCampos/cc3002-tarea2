package model.player.type;

public class HumanPlayer extends AbstractPlayer {
  
  public HumanPlayer() {
    super();
  }
}
