package model.card.type;

public class NumericCard extends AbstractCard {
  
  public NumericCard(Color color, Symbol symbol) {
    this.color = color;
    this.symbol = symbol;
  }

  
}
